package com.company.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.company.dao.Milk_dao;

public class Test extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public Test() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		action(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		action(request, response);
	}

	protected void action(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("정상");

		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");

		String path = request.getServletPath();
		if (path.equals("/list.milk")) {
			Milk_dao dao = new Milk_dao();

			request.setAttribute("dto_list", dao.list());
			request.getRequestDispatcher("/milk/milks.jsp").forward(request, response);
			System.out.println("잘넘겼음");
		} else if (path.equals("/insert.milk")) {

			request.getRequestDispatcher("/list.milk").forward(request, response);

		} else if (path.equals("/detail.milk")) {

			request.getRequestDispatcher("/milk_select.jsp").forward(request, response);

		} else if (path.equals("/edit.milk")) {

			request.getRequestDispatcher("/list.milk").forward(request, response);

		} else if (path.equals("/delete.milk")) {

			request.getRequestDispatcher("/list.milk").forward(request, response);

		}

	}

}
