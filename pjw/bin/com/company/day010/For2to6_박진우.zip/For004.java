package com.company.day010;

public class For004 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int j = 0;
		for (int i = 1; i <= 10; i++) {
			j = j + i;
		}

		System.out.println("1~10까지 합 : " + j);

	}
}
