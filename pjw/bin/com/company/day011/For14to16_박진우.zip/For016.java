package com.company.day011;

import java.util.Scanner;

public class For016 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 변수
		Scanner sc = new Scanner(System.in);
		int stdid, kor, eng, math, tot, level;
		float avg;

		// 입력
		System.out.println("학번 > ");
		stdid = sc.nextInt();

		for (;;) {
			System.out.println("국어 > ");
			kor = sc.nextInt();
			if (0 <= kor && kor <= 100) {
				break;
			}
		}
		for (;;) {
			System.out.println("영어 > ");
			eng = sc.nextInt();
			if (0 <= eng && eng <= 100) {
				break;
			}
		}

		for (;;) {
			System.out.println("수학 > ");
			math = sc.nextInt();
			if (0 <= math && math <= 100) {
				break;
			}
		}

		// 처리
		tot = kor + eng + math;
		avg = (float) tot / 3;

		// 출력
		System.out.println("학번\t국어\t영어\t수학\t총점\t평균");

		System.out.print("std" + stdid + "\t" + kor + "\t" + eng + "\t" + math + "\t" + tot + "\t");
		System.out.printf("%.2f", avg);

		sc.close();

	}

}
