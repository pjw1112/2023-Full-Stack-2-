package com.company.day023;


class MyPrice001{
	String name="노트20";
	int price=100000;
	
	void show() {
		System.out.println("이름 : "+name+"\n가격 : "+price);
	}
}

public class Class005 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyPrice001 mp1 = new MyPrice001();
		mp1.show();

	}

}
