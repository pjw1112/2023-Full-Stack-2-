package com.company.day023;


class Coffee001{
	String name="아메리카노";
	int price=2000;
	
	void show() {
		System.out.println("커피명 : "+name+"\n커피가격 : "+price);
	}
}

public class Class006 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Coffee001 mp1 = new Coffee001();
		mp1.show();

	}

}