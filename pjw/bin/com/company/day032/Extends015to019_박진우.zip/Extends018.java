package com.company.day032;

final class Papa018{}
//class SonFinal extends Papa018{} 상수 클래스는 상속할 수 없다




public class Extends018 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
