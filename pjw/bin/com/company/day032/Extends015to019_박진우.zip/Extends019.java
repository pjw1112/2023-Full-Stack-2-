package com.company.day032;

public class Extends019 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//상수 메서드를 오버라이딩 할 수 없음
	}

}
